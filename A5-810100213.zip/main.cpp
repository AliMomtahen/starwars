#include"./src/rsdl.hpp"
#include"./classes/Ship.hpp"
#include"./classes/Enemy.hpp"
#include"./classes/Game.hpp"
#include"./classes/Shot.hpp"
#include"func.hpp"

#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<ctime>

using namespace std;




int main(int argc , char *argv[] ){




    

    
    std::ifstream  map;
    map.open((std::string) argv[1]);
    int row , column;
    get_input( map , row , column);
    Game game(row * CELL_SIZE , column * CELL_SIZE , SHIP_SHAPE);
    game.run(map);

      
   
    return 0;
}